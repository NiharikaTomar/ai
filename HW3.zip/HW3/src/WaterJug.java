////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW3 WatreJug.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Due date: februray 26 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
 * This class aims to implement the WaterJug prompt given in HW3. Consists of
 * variety of conditions to ensure proper working of the program.
 * 
 * @author niharikatomar
 */

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Stack;

class State {
	int cap_jug1;
	int cap_jug2;
	int curr_jug1;
	int curr_jug2;
	int goal;
	int depth;
	State parentPt;

	public State(int cap_jug1, int cap_jug2, int curr_jug1, int curr_jug2, int goal, int depth, State parent) {
		this.cap_jug1 = cap_jug1;
		this.cap_jug2 = cap_jug2;
		this.curr_jug1 = curr_jug1;
		this.curr_jug2 = curr_jug2;
		this.goal = goal;
		this.depth = depth;
		this.parentPt = parent;
	}

	/*
	 * helper method to compare successors for the getSuccessors function
	 */
	private boolean successorComp(State check, State[] container) {
		// checking if container array is empty
		if (container.length == 0) {
			return true;
		}
		// loop to check through every element of container array
		for (int counter = 0; counter < container.length; counter++) {
			if (container[counter] == null) {
				return true;
			}
			if (check.curr_jug2 == container[counter].curr_jug2 && check.curr_jug1 == container[counter].curr_jug1) {
				return false;
			}
		}
		return true;
	}

	public State[] getSuccessors() {
		// list to hold states
		ArrayList<State> visited = new ArrayList<State>();
		// Checking if jug1 can be emptied
		if (this.curr_jug1 > 0) {
			State e1 = new State(this.cap_jug1, this.cap_jug2, 0, this.curr_jug2, this.goal, this.depth + 1, this);
			visited.add(e1);
		}

		// Check if jug with higher capacity(in this case jug1) can fill jug with lesser
		// capacity (in this case jug2)
		if (this.curr_jug1 > 0 && this.curr_jug2 < this.cap_jug2) {
			// Condition check if jug1 has remaining water after filling jug1
			if (this.curr_jug1 > this.cap_jug2 || this.curr_jug1 + this.curr_jug2 >= this.cap_jug2) {
				int jug2 = this.cap_jug2;
				int jug1 = this.curr_jug1 - (this.cap_jug2 - this.curr_jug2);
				State p12 = new State(this.cap_jug1, this.cap_jug2, jug1, jug2, this.goal, this.depth + 1, this);
				visited.add(p12);
			}
			// Condition check if jug2 has no remaining water after filling jug1
			else if (this.curr_jug1 + this.curr_jug2 < this.cap_jug2) {
				int jug2 = this.curr_jug1 + this.curr_jug2;
				State p12 = new State(this.cap_jug1, this.cap_jug2, 0, jug2, this.goal, this.depth + 1, this);
				visited.add(p12);
			}
		}

		// Checking if jug2 can be emptied
		if (this.curr_jug2 > 0) {
			State e2 = new State(this.cap_jug1, this.cap_jug2, this.curr_jug1, 0, this.goal, this.depth + 1, this);
			visited.add(e2);
		}
		// Checking the possibility of filling up jug2
		if (this.curr_jug2 >= 0 && this.curr_jug2 < this.cap_jug2) {
			State f2 = new State(this.cap_jug1, this.cap_jug2, this.curr_jug1, this.cap_jug2, this.goal, this.depth + 1,
					this);
			visited.add(f2);
		}

		// Check if jug with higher capacity(in this case jug2) can fill jug with lesser
		// capacity (in this case jug2)
		if (this.curr_jug2 > 0 && this.curr_jug1 < this.cap_jug1) {
			// Condition check if jug2 has remaining water after filling jug1
			if (this.curr_jug2 > this.cap_jug1 || this.curr_jug1 + this.curr_jug2 >= this.cap_jug1) {
				int jug1 = this.cap_jug1;
				int jug2 = this.curr_jug2 - (this.cap_jug1 - this.curr_jug1);
				State p21 = new State(this.cap_jug1, this.cap_jug2, jug1, jug2, this.goal, this.depth + 1, this);
				visited.add(p21);
			}
			// Condition check if jug2 has no remaining water after filling jug1
			else if (this.curr_jug1 + this.curr_jug2 < this.cap_jug1) {
				int jug1 = this.curr_jug1 + this.curr_jug2;
				State p21 = new State(this.cap_jug1, this.cap_jug2, jug1, 0, this.goal, this.depth + 1, this);
				visited.add(p21);
			}
		}
		// Checking the possibility of filling up jug1
		if (this.curr_jug1 >= 0 && this.curr_jug1 < this.cap_jug1) {
			State f1 = new State(this.cap_jug1, this.cap_jug2, this.cap_jug1, this.curr_jug2, this.goal, this.depth + 1,
					this);
			visited.add(f1);
		}

		// successors array of type State keeping track of size of the list
		State[] successor = new State[visited.size()];
		// loop to get value of Successor function (given by the table in HW3
		// description)
		for (int cur = 0; cur < visited.size(); cur++) {
			if (successorComp(visited.get(cur), successor)) {
				successor[cur] = visited.get(cur);
			}
		}
		return successor;
	}

	public boolean isGoalState() {
		// Determining if the state is a goal node or not and return boolean
		return (this.curr_jug2 == this.goal || this.curr_jug1 == this.goal);
	}

	public void printState(int option, int depth) {
		// printing a State based on option (flag)
		UninformedSearch.printSearch(this, option, depth);
	}

	public String getOrderedPair() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.curr_jug1);
		builder.append(this.curr_jug2);
		return builder.toString().trim();
	}

	public void pathLength(State end) {
		if (end.parentPt == null) { // if last state, print the path
			System.out.print(Integer.toString(end.curr_jug1) + "" + Integer.toString(end.curr_jug2));
			return;
		}
		// if not last state, recursively call function till last state reached to print
		// out the path
		String edit = Integer.toString(end.curr_jug1) + "" + Integer.toString(end.curr_jug2);
		pathLength(end.parentPt); // recursive call
		System.out.print(" " + edit); // printing path
	}
}

class UninformedSearch {

	private static void bfs(State curr_state) {
		// run breadth-first search algorithm(bfs)
		// Start
		ArrayDeque<State> queue = new ArrayDeque<State>();
		queue.add(curr_state);
		// array to store each successor list
		State[] pos = new State[0];
		// Used to print the path out
		ArrayList<String> path = new ArrayList<String>();
		// list to print the Queue out
		ArrayList<String> Queue = new ArrayList<String>();
		// set to Store the current path in use
		HashSet<State> curPath = new HashSet<>();
		System.out.println(curr_state.curr_jug1 + "" + curr_state.curr_jug2);
		// condition check to see if queue empty(bfs)
		while (!queue.isEmpty()) {
			// get out the first element in Queue
			State first = queue.remove();
			curPath.add(first); // incrementing set
			String edit = Integer.toString(first.curr_jug1) + Integer.toString(first.curr_jug2);
			path.add(edit); // incrementing path list
			// Check if goal state reached
			if (first.isGoalState()) {
				System.out.println(edit + " Goal");
				curPath.add(first);
				// Printing out final path
				System.out.print("Path ");
				first.pathLength(first);
				break; // exit loop
			}

			// Get all possible next elements(successors)
			pos = first.getSuccessors();
			// Removing (if any) duplicates from the Queue set
			for (int k = 0; k < pos.length; k++) {
				String edit2 = Integer.toString(pos[k].curr_jug1) + Integer.toString(pos[k].curr_jug2);
				if (Queue.contains(edit2) || path.contains(edit2)) {
					continue;
				}
				queue.add(pos[k]); // incrementing Array queue
				Queue.add(edit2); // incrementing Queue list
			}

			// Printing out the current Queue list
			System.out.print(edit + " [");
			for (int k = 0; k < queue.size(); k++) {
				if (k + 1 == queue.size()) {
					System.out.print(Queue.get(k) + "]");
					break;
				}
				System.out.print(Queue.get(k) + ","); // printing all elements of list
			}
			Queue.remove(0);// removing first element from list
			// Printing out the path of states taken so far
			System.out.print(" [");
			for (int k = 0; k < curPath.size(); k++) {
				if (k + 1 == curPath.size()) {
					System.out.println(path.get(k) + "]");
					break; // exit loop
				}
				System.out.print(path.get(k) + ",");
			}
		}
	}

	private static void dfs(State curr_state) {
		// run depth-first search algorithm
		// Start
		Stack<State> stack = new Stack<State>(); // lifo type
		stack.push(curr_state); // adding element to Stack
		// Storing each successor list
		State[] pos = new State[0];
		// Used to print the path out
		ArrayList<String> path = new ArrayList<String>();
		// set to Store the current path in use
		HashSet<State> curPath = new HashSet<State>();
		// Used to print the stack out
		ArrayList<String> Stack = new ArrayList<String>();
		// Print out starting state
		System.out.println(curr_state.curr_jug1 + "" + curr_state.curr_jug2);
		// condition check for stack to be empty
		while (!stack.isEmpty()) {
			// getting out the first element in stack
			State check = stack.pop();
			curPath.add(check);
			String edit = Integer.toString(check.curr_jug1) + Integer.toString(check.curr_jug2);
			path.add(edit);
			// Check if reached goal state
			if (check.isGoalState()) {
				System.out.println(edit + " Goal");
				curPath.add(check);
				// Print out final path
				System.out.print("Path ");
				check.pathLength(check);
				break; // exit loop
			}
			// Getting all possible next elements(successors)
			pos = check.getSuccessors();
			// Remove (if any) duplicates from the stack list
			for (int cur = 0; cur < pos.length; cur++) {
				String edit2 = Integer.toString(pos[cur].curr_jug1) + Integer.toString(pos[cur].curr_jug2);
				if (Stack.contains(edit2) || path.contains(edit2)) { // condition check
					continue;
				}
				stack.add(pos[cur]); // incrementing stack list with cur element in pos array
				Stack.add(edit2); // incrementing stack list with edit2
			}

			// Print out the current Queue
			System.out.print(edit + " [");
			for (int k = 0; k < stack.size(); k++) {
				if (k + 1 == stack.size()) {
					System.out.print(Stack.get(k) + "]");
					break;
				}
				System.out.print(Stack.get(k) + ",");
			}
			// removing last element from stack
			Stack.remove((Stack.size()) - 1);
			// Printing out the path of all the states taken so far
			System.out.print(" [");
			// loop for iteration
			for (int cur = 0; cur < curPath.size(); cur++) {
				if (cur + 1 == curPath.size()) {
					System.out.println(path.get(cur) + "]");
					break;
				}
				System.out.print(path.get(cur) + ",");
			}
		}
	}

	private static void iddfs(State curr_state, int depth) {
		// States if goal has been found
		boolean reached = false;

		// The outer loop used to count the depths
		for (int depthCount = 0; depthCount < depth; depthCount++) {
			if (reached) {
				break;
			}
			// Starting place
			Stack<State> stack = new Stack();
			stack.push(curr_state);

			// Stores each successor list
			State[] pos = new State[0];
			// Used to print the path out
			ArrayList<String> path = new ArrayList<String>();
			// set to Store the current path in use
			HashSet<State> curPath = new HashSet<State>();
			// Used to print the stack out
			ArrayList<String> Stack = new ArrayList<String>();

			// Printing out start state
			System.out.println(depthCount + ":" + curr_state.curr_jug1 + "" + curr_state.curr_jug2);

			// stack to be empty condition check
			while (!stack.isEmpty()) { // lifo type
				State check = stack.pop(); // get out the first in stack
				if (depthCount == 0) {
					String edit = Integer.toString(check.curr_jug1) + Integer.toString(check.curr_jug2);
					System.out.print(depthCount + ":" + edit + " [] ");
					System.out.println("[" + edit + "]");
					continue;
				} //checking depth count
				if (check.depth <= depthCount) {
					curPath.add(check); //incrementing set
					String edit = Integer.toString(check.curr_jug1) + Integer.toString(check.curr_jug2);
					path.add(edit); // incrementing path list
					// Checking if goal state is reached
					if (check.isGoalState()) {
						System.out.println(depthCount + ":" + edit + " Goal");
						curPath.add(check);
						// Printing out final path
						System.out.print("Path ");
						check.pathLength(check);
						reached = true;
						break; // exit loop
					}
					// Get all possible next element states
					pos = check.getSuccessors();
					// Removing (if any) duplicates from the array pos
					for (int k = 0; k < pos.length; k++) {
						String edit2 = Integer.toString(pos[k].curr_jug1) + Integer.toString(pos[k].curr_jug2);
						if (Stack.contains(edit2) || path.contains(edit2) || pos[k].depth > depthCount) {
							continue;
						}
						stack.add(pos[k]); //array incrementing
						Stack.add(edit2); //array incrementing
					}
				}
				// Print out the current queue
				String edit = Integer.toString(check.curr_jug1) + Integer.toString(check.curr_jug2);
				System.out.print(depthCount + ":" + edit + " [");
				//loop iteration to get every element id stack array
				for (int cur = 0; cur < stack.size(); cur++) {
					if (cur + 1 == stack.size()) {
						System.out.print(Stack.get(cur) + "]");
						break; //exit loop
					}
					System.out.print(Stack.get(cur) + ",");
				}
				// if our stack is empty print ]
				if (stack.isEmpty()) {
					System.out.print("]");
					}// if our stack isn't empty and still has elements, pop elements
				else if (!Stack.isEmpty()) {
					Stack.remove(Stack.size() - 1);
				}
				// else exit
				else {
					System.out.println(edit + "]");
					break; //exiting loop
				}
				// Printing out the path of the states taken so far
				System.out.print(" [");
				for (int i = 0; i < curPath.size(); i++) {
					if (i + 1 == curPath.size()) {
						System.out.println(path.get(i) + "]");
						break; //exit loop
					}
					System.out.print(path.get(i) + ",");
				}
			}
		}
	}

	public static void printSearch(State curr_state, int option, int depth) {

		// Get all of our successors aka next elemental states
		if (option == 1) {
			State[] successor = curr_state.getSuccessors();
			for (int i = 0; i < successor.length; i++) {
				System.out.println(successor[i].curr_jug1 + "" + successor[i].curr_jug2);
			}
		}

		// Get all the successor states and check if any of them is our goal state
		else if (option == 2) {
			State[] successor = curr_state.getSuccessors();
			for (int cur = 0; cur < successor.length; cur++) {
				System.out.println(
						successor[cur].curr_jug1 + "" + successor[cur].curr_jug2 + " " + successor[cur].isGoalState());
			}
		}
		// Attempt a BFS
		else if (option == 3) {
			bfs(curr_state);
		}
		// Attempt a DFS
		else if (option == 4) {
			dfs(curr_state);
		}
		// Attempt an IDDFS
		else if (option == 5) {
			iddfs(curr_state, depth);
		}
	}
}

public class WaterJug {

	public static void main(String args[]) {
		if (args.length != 6) {
			System.out.println("Invalid Number of Input Arguments");
			return;
		}
		int flag = Integer.valueOf(args[0]);
		int cap_jug1 = Integer.valueOf(args[1]);
		int cap_jug2 = Integer.valueOf(args[2]);
		int curr_jug1 = Integer.valueOf(args[3]);
		int curr_jug2 = Integer.valueOf(args[4]);
		int goal = Integer.valueOf(args[5]);

		int option = flag / 100;
		int depth = flag % 100;

		if (option < 1 || option > 5) {
			System.out.println("Invalid flag input");
			return;
		}
		if (cap_jug1 > 9 || cap_jug2 > 9 || curr_jug1 > 9 || curr_jug2 > 9) {
			System.out.println("Invalid input: 2-digit jug volumes");
			return;
		}
		if (cap_jug1 < 0 || cap_jug2 < 0 || curr_jug1 < 0 || curr_jug2 < 0) {
			System.out.println("Invalid input: negative jug volumes");
			return;
		}
		if (cap_jug1 < curr_jug1 || cap_jug2 < curr_jug2) {
			System.out.println("Invalid input: jug volume exceeds its capacity");
			return;
		}
		State init = new State(cap_jug1, cap_jug2, curr_jug1, curr_jug2, goal, 0, null);
		init.printState(option, depth);
	}
}