////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW9 BodyVsBrain.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
 * This class aims to implement the BodyVsBrain prompt given in HW9. Consists of
 * variety of conditions to ensure proper working of the program.
 * 
 * @author niharikatomar
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

/**
 * Class that calls various methods, each of which manipulate and learn from the
 * given data on the bodies and brains of the species given.
 * 
 * @author
 *
 */
public class BodyVsBrain {

	/**
	 * Reads the data.csv file
	 * 
	 * @return data
	 */
	private static List<List<String>> readData() {
		List<List<String>> given = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(
				new FileReader("/Users/niharikatomar/Desktop/cs 400/HW9/src/data.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");
				given.add(Arrays.asList(values));
			}
		} catch (FileNotFoundException ex) {
			System.out.println("File Not Found.");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return given;
	}

	/**
	 * The main runs certain data analysis based on the given flag and arguments.
	 * 
	 * @param args:
	 *            Flag, and optionally, b0, b1, eta, t, body weight
	 */
	static public void main(String[] args) {
		List<List<String>> data = readData();
		int flag = Integer.valueOf(args[0]);

		double brainSum = 0;
		double bodySum = 0;
		int count = data.size() - 1;

		// Create two separate lists for brains and body
		ArrayList<Double> brain = new ArrayList<>();
		ArrayList<Double> body = new ArrayList<>();

		// For loop to catch the total sum of each category as well as
		// storing each into their respective lists
		for (int i = 0; i < data.size(); i++) {
			if (i == 0) {
				continue;
			}
			bodySum += Double.parseDouble(data.get(i).get(0));
			body.add(Double.parseDouble(data.get(i).get(0)));

			brainSum += Double.parseDouble(data.get(i).get(1));
			brain.add(Double.parseDouble(data.get(i).get(1)));
		}

		// Store the mean for each variable
		double bodyMean = getMean(bodySum, count);
		double brainMean = getMean(brainSum, count);

		// Store std deviation for each variable
		double bodyStdev = getStdev(bodyMean, body);
		double brainStdev = getStdev(brainMean, brain);

		// Used to format all printed decimals
		DecimalFormat format = new DecimalFormat("0.0000");

		// Calls to print out the count, means, and standard deviations
		if (flag == 100) {

			System.out.println(count);
			System.out.println(format.format(bodyMean) + " " + format.format(bodyStdev));
			System.out.println(format.format(brainMean) + " " + format.format(brainStdev));

		}

		// Prints out the MSE based on the current data and the two
		// values b0 and b1
		if (flag == 200) {
			double b1 = Double.valueOf(args[1]);
			double b2 = Double.valueOf(args[2]);

			System.out.println(format.format(getMSE(b1, b2, body, brain)));
		}

		// Prints out the partial derivatives of the MSE
		if (flag == 300) {
			double b1 = Double.valueOf(args[1]);
			double b2 = Double.valueOf(args[2]);

			System.out.println(format.format(partialMSE(b1, b2, body, brain, -1)));
			System.out.println(format.format(partialMSE2(b1, b2, body, brain, -1)));
		}

		// Performs a gradient descent using eta and t, starting at (b0, b1)
		// equaling (0,0)
		if (flag == 400) {
			double eta = Double.valueOf(args[1]);
			int t = Integer.valueOf(args[2]);
			ArrayList<Double> temp = new ArrayList<>();

			for (int i = 1; i <= t; i++) {
				if (i == 1) {
					temp = gradDescent(i, eta, 0.0, 0.0, body, brain, -1);
				} else {
					temp = gradDescent(i, eta, temp.get(0), temp.get(1), body, brain, -1);
				}
				System.out.println(i + " " + (format.format(temp.get(0))) + " " + format.format(temp.get(1)) + " "
						+ format.format(temp.get(2)));
			}
		}

		// Performs a closed-form solution
		if (flag == 500) {

			ArrayList<Double> values = OrdLeast(bodyMean, brainMean, body, brain);

			for (double value : values) {
				System.out.print(format.format(value) + " ");
			}
		}

		// Performs a closed-form solution using a given body weight
		if (flag == 600) {
			double predict = Double.valueOf(args[1]);

			ArrayList<Double> values = OrdLeast(bodyMean, brainMean, body, brain);

			double value = values.get(0) + (values.get(1) * predict);

			System.out.println(format.format(value));
		}

		// Performs a gradient descent like in 400 using a normalized set for
		// the body weights
		if (flag == 700) {
			double eta = Double.valueOf(args[1]);
			int t = Integer.valueOf(args[2]);
			ArrayList<Double> normalized = new ArrayList<>();

			for (double value : body) {
				normalized.add(normalize(value, bodyMean, bodyStdev));
			}

			ArrayList<Double> temp = new ArrayList<>();

			for (int i = 1; i <= t; i++) {
				if (i == 1) {
					temp = gradDescent(i, eta, 0.0, 0.0, normalized, brain, -1);
				} else {
					temp = gradDescent(i, eta, temp.get(0), temp.get(1), normalized, brain, -1);
				}
				System.out.println(i + " " + (format.format(temp.get(0))) + " " + format.format(temp.get(1)) + " "
						+ format.format(temp.get(2)));
			}
		}

		// Performs a gradient descent like 700, this time using a random
		// (x, y) pair in the partial derivative MSE portion
		if (flag == 800) {
			double eta = Double.valueOf(args[1]);
			int t = Integer.valueOf(args[2]);
			ArrayList<Double> normalized = new ArrayList<>();

			Random rand = new Random();
			int n = rand.nextInt(body.size() + 1);

			for (double value : body) {
				normalized.add(normalize(value, bodyMean, bodyStdev));
			}

			ArrayList<Double> temp = new ArrayList<>();

			for (int i = 1; i <= t; i++) {
				if (i == 1) {
					temp = gradDescent(i, eta, 0.0, 0.0, normalized, brain, n);
				} else {
					temp = gradDescent(i, eta, temp.get(0), temp.get(1), normalized, brain, n);
				}
				System.out.println(i + " " + (format.format(temp.get(0))) + " " + format.format(temp.get(1)) + " "
						+ format.format(temp.get(2)));
			}
		}
	}

	/**
	 * Captures the mean of the given values
	 * 
	 * @param sum:
	 *            sum of all values given
	 * @param count:
	 *            count of all values given
	 * @return mean
	 */
	private static double getMean(double sum, double count) {
		return sum / count;
	}

	/**
	 * Captures the standard deviation of a given list of values
	 * 
	 * @param mean:
	 *            used to subtract from each value in list
	 * @param numList:
	 *            compared with mean
	 * @param count:
	 *            count of all values in list
	 * @return standard deviation
	 */
	private static double getStdev(double mean, ArrayList<Double> numList) {
		double varSum = 0;

		for (Double num : numList) {
			double temp = (num - mean);
			varSum += Math.pow(temp, 2);
		}
		double variance = varSum / (numList.size() - 1);

		return Math.sqrt(variance);
	}

	/**
	 * 
	 * @param b1
	 * @param b2
	 * @param bodies
	 * @param brains
	 * @return
	 */
	private static double getMSE(double b0, double b1, ArrayList<Double> bodies, ArrayList<Double> brains) {
		double MSESum = 0;
		for (int i = 0; i < bodies.size(); i++) {
			double temp = b0 + (b1 * bodies.get(i)) - brains.get(i);
			MSESum += Math.pow(temp, 2);
		}

		return MSESum / bodies.size();
	}

	/**
	 * 
	 * @param b1
	 * @param b2
	 * @param bodies
	 * @param brains
	 * @return
	 */
	private static double partialMSE(double b0, double b1, ArrayList<Double> bodies, ArrayList<Double> brains, int n) {
		double MSESum = 0;

		if (n != -1) {
			double xjt = bodies.get(n);
			double yjt = brains.get(n);

			return 2 * (b0 + (b1 * xjt) - yjt);
		}
		for (int i = 0; i < bodies.size(); i++) {
			double temp = b0 + (b1 * bodies.get(i)) - brains.get(i);
			MSESum += temp;
		}

		return 2 * MSESum / bodies.size();
	}

	/**
	 * 
	 * @param b1
	 * @param b2
	 * @param bodies
	 * @param brains
	 * @return
	 */
	private static double partialMSE2(double b0, double b1, ArrayList<Double> bodies, ArrayList<Double> brains, int n) {
		double MSESum = 0;

		if (n != -1) {
			double xjt = bodies.get(n);
			double yjt = brains.get(n);

			return 2 * (b0 + (b1 * xjt) - yjt) * xjt;
		}

		for (int i = 0; i < bodies.size(); i++) {
			double temp = b0 + (b1 * bodies.get(i)) - brains.get(i);
			MSESum += temp * bodies.get(i);
		}

		return 2 * MSESum / bodies.size();
	}

	private static ArrayList<Double> gradDescent(int t, double eta, double b0, double b1, ArrayList<Double> bodies,
			ArrayList<Double> brains, int n) {
		ArrayList<Double> descentVals = new ArrayList<>();

		double tempb0 = b0;
		double tempb1 = b1;
		double tempMSE1 = 0;
		double tempMSE2 = 0;

		if (n != -1) {
			tempMSE1 = partialMSE(b0, b1, bodies, brains, n);
			tempMSE2 = partialMSE2(b0, b1, bodies, brains, n);
		} else {
			tempMSE1 = partialMSE(b0, b1, bodies, brains, -1);
			tempMSE2 = partialMSE2(b0, b1, bodies, brains, -1);
		}

		double b0t = tempb0 - (eta * tempMSE1);
		double b1t = tempb1 - (eta * tempMSE2);

		descentVals.add(b0t);
		descentVals.add(b1t);
		descentVals.add(getMSE(b0t, b1t, bodies, brains));

		return descentVals;
	}

	private static ArrayList<Double> OrdLeast(double bodyMean, double brainMean, ArrayList<Double> bodies,
			ArrayList<Double> brains) {
		ArrayList<Double> values = new ArrayList<>();
		double numerator = 0;
		double denominator = 0;

		for (int i = 0; i < bodies.size(); i++) {
			double xTemp = bodies.get(i) - bodyMean;
			double yTemp = brains.get(i) - brainMean;

			numerator += (xTemp * yTemp);
			denominator += Math.pow(xTemp, 2);
		}

		double b1 = numerator / denominator;
		double b0 = brainMean - (b1 * bodyMean);
		double MSE = getMSE(b0, b1, bodies, brains);

		values.add(b0);
		values.add(b1);
		values.add(MSE);

		return values;
	}

	private static double normalize(double x, double bodyMean, double stdev) {
		return (x - bodyMean) / stdev;
	}
}
