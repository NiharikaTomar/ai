////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW4 EightQueen.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Due date: March 5 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
 * This class aims to implement the EightQueen prompt given in HW4. Consists of
 * variety of conditions to ensure proper working of the program.
 * 
 * @author niharikatomar
 */

import java.util.*;

class State {
	char[] board;

	public State(char[] arr) {
		this.board = Arrays.copyOf(arr, arr.length);
	}

	public void printState(int option, int iteration, int seed) {
		// displaying heuristic cost as outlined in part a) of HW4
		if (option == 1) {
			System.out.println(heuristicCost(board));

		}
		// displaying lowest heuristic cost as outlined in part b) of HW4
		else if (option == 2) {
			if (heuristicCost(board) == 0) { // condition check
				return;
			}
			// getting current heuristic cost of board
			int heuristic = heuristicCost(board);
			// getting lowest cost for next state
			int least = minimumCost(board, heuristic);
			// getting all States with cost equal to the lowest Cost in a list
			ArrayList<State> matchFound = minState(board, least);
			// loop to display all results
			for (int i = 0; i < matchFound.size(); i++) {
				if (matchFound.get(i) != null) { // condition check
					System.out.println(matchFound.get(i).board);
				}
			}
			System.out.println(least);
		}
		// hill climbing algorithm implementation as outlined in part c) of HW4
		else if (option == 3) {
			// list to store outputs of algo
			ArrayList<State> temp = new ArrayList<State>();
			// getting current heuristic cost of the board
			int curr = heuristicCost(board);
			if (curr == 0) { // if current cost id 0 then it is the lowest possible cost so print solved and
								// exit
				status(board, 0, curr); // printing the status thus far
				System.out.println("Solved");
				return;
			} else { // if current lowest cost is not 0 then add to the vector list
				State start = new State(board);
				temp.add(start); // adding to vector list
			}
			// getting lowest heuristic cost for current cost
			int least = minimumCost(board, curr);
			int counter = 0; // keeping track of number of times iterations are done
			// list to collect all possible steepest moves
			ArrayList<State> successors = minState(board, least);
			// set Random
			Random rand = new Random();
			if (seed != -1)
				rand.setSeed(seed);
			int generate = rand.nextInt(successors.size());
			State move = successors.get(generate);
			// while loop for implementation of hill climbing algo
			while (!(counter >= iteration)) { // making sure counter check of iterations doesn't exceed given iteration
				temp.add(move); // adding move to vector
				if (least == 0) { // if lowest cost found, exit the loop
					break; // exit condition
				}
				least = minimumCost(move.board, least);// updating least cost
				successors = minState(move.board, least); // updating successor
				if (successors.size() != 0) { // condition check
					generate = rand.nextInt(successors.size());
					move = successors.get(generate);
				}
				counter++; // incrementing iteration
				if (least == 0) { // if least cost found
					temp.add(move); // add to list and break
					break; // exit loop
				}
			}
			// loop iteration for status print
			for (int i = 0; i < temp.size(); i++) {
				status(temp.get(i).board, i, heuristicCost(temp.get(i).board));
			}
			if (least == 0) { // if least cost found
				System.out.println("Solved"); // print solved
			}
		}
		// first-choice hill climbing algorithm implementation as outlined in part d) of
		// HW4
		else if (option == 4) {
			// list to store outputs of algo
			ArrayList<State> temp = new ArrayList<State>();
			// getting current heuristic cost of the board
			int curr = heuristicCost(board);
			int counter = 0; // keeping track of number of times iterations are done
			boolean localMax = false;
			State start = new State(board); // initial board
			if (curr == 0) { // if least cost found
				status(board, 0, curr); // get board status
				System.out.println("Solved"); // print solved
				return;
			} else {
				temp.add(start); // adding to vector list
			}
			// getting the first-choice as our next State
			State next = getNext(start, curr); // getting next state
			int nextCost = heuristicCost(next.board); // getting cost of our next state
			while (counter < iteration && nextCost <= curr) {
				next = getNext(next, curr); // getting next cost
				if (next != null) { // null check
					curr = heuristicCost(next.board); // getting current heuristic cost
					nextCost = heuristicCost(next.board); // getting next cost
					temp.add(next);
					localMax = false;
				} else {
					localMax = true;
					break; // exit loop
				}
				counter++; // increment iteration counter
			}
			// printing status thus far
			for (int i = 0; i < temp.size(); i++) {
				status(temp.get(i).board, i, heuristicCost(temp.get(i).board));
			}
			if (curr == 0) { // if lowest heuristic cost found
				System.out.println("Solved"); // print Solved
			} else if (localMax) { // if local max is found
				System.out.println("Local optimum"); // print local optimum
			}
		}
		// simulated annealing algorithm implementation as outlined in part e) of HW4
		else if (option == 5) {
			double annealRate = 0.95;
			double T = 100; // temperature
			int deltaE = 0;
			int counter = 0;
			State curr = new State(board);
			int currCost = heuristicCost(curr.board);
			int nextCost = 100;
			ArrayList<State> temp = new ArrayList<State>();
			int cost = heuristicCost(board);
			if (cost == 0) {
				status(board, 0, cost);
				System.out.println("Solved");
				return;
			} else {
				temp.add(curr);
			}
			// seed set
			Random rand = new Random();
			if (seed != -1)
				rand.setSeed(seed);
			while (counter < iteration) {
				T = T - annealRate;
				if (T <= 0) {
					break; // exit case
				}
				// get initial random change
				int index = rand.nextInt(7);
				int val = rand.nextInt(7);
				double edit = rand.nextDouble();
				// setting initial next State
				State next = new State(curr.board);
				next.board[index] = Integer.toString(val).toCharArray()[0];
				nextCost = heuristicCost(next.board);
				deltaE = nextCost - currCost;
				if (deltaE <= 0) {
					// if better state found
					temp.add(next);
					curr = next;
					currCost = nextCost;
				} else {
					// setting current to be next according to edit
					double uBound = Math.exp(deltaE);
					double lBound = 1;
					double editThresh = Math.exp(deltaE / T);
					double scaledThresh = 1 - (uBound - editThresh) / (uBound - lBound);
					if (edit > scaledThresh) {
						// assuming its better state
						temp.add(next);
						curr = next; // update
						currCost = nextCost; // setting current cost to be next cost
					} else {
						temp.add(curr);
					}
				}
				counter++; // increment counter of iterations
			}
			for (int i = 0; i < temp.size(); i++) { // loop to print current status
				status(temp.get(i).board, i, heuristicCost(temp.get(i).board));
			}
			if (currCost == 0) { // if least cost found
				System.out.println("Solved"); // print solved
			}
		}
	}

	// helper method get the next first-choice
	private State getNext(State curr, int currCost) {
		int nextCost = 100;
		char[] m = Arrays.copyOf(curr.board, curr.board.length);
		for (int row = 0; row < curr.board.length; row++) {
			for (int j = 0; j < curr.board.length; j++) {
				m[row] = Integer.toString(j).toCharArray()[0];
				nextCost = heuristicCost(m);
				if (nextCost < currCost) {
					State next = new State(m);
					return next;
				}
			}
			m = Arrays.copyOf(curr.board, curr.board.length);
		}
		return null;
	}

	// helper method to print out the result/board status
	private void status(char[] board, int iter, int minCost) {
		String s1 = new String(board);
		System.out.print(iter + ":" + s1 + " " + minCost);
		System.out.println();
	}

	// helper method for getting the states with their given cost
	private ArrayList<State> minState(char[] board, int minCost) {
		int potCost = 100;
		boolean check = false;
		// new list
		ArrayList<State> temp = new ArrayList<State>();
		char[] m = Arrays.copyOf(board, board.length); // new board initialization
		for (int row = 0; row < board.length; row++) { // new board's iteration
			for (int j = 0; j < board.length; j++) {
				m[row] = Integer.toString(j).toCharArray()[0];
				potCost = heuristicCost(m); // potential cost
				if (potCost == minCost) { // condition check
					State next = new State(m);
					for (int i = 0; i < temp.size(); i++) {
						if (Arrays.equals(next.board, temp.get(i).board)) {
							check = true;
						}
					}
					if (!check) {
						temp.add(next);
					}
					check = false;
				}
			}
			m = Arrays.copyOf(board, board.length);
		}
		for (int i = 0; i < temp.size(); i++) {
			if (Arrays.equals(temp.get(i).board, board)) {
				temp.remove(i);
			}
		}
		return temp;
	}

	// helper method for getting the lowest/minimum heuristic cost
	private int minimumCost(char[] board, int minCost) {
		int potCost = 100; // potential cost
		char[] m = Arrays.copyOf(board, board.length); // new board
		for (int row = 0; row < board.length; row++) { // new board iteration
			for (int j = 0; j < board.length; j++) {
				m[row] = Integer.toString(j).toCharArray()[0]; // converting from int to char
				potCost = heuristicCost(m); // setting our potential cost to the heuristic cost of the board initialsed
											// currently
				if (potCost < minCost) {
					minCost = potCost; // updating minimum cost
				}
			}
			m = Arrays.copyOf(board, board.length); // updating m
		}
		return minCost; // returning least cost
	}

	// helper method for getting heuristic cost of the given state
	private int heuristicCost(char[] board) {
		int currCost = 0; // current cost
		for (int row = 0; row < board.length; row++) {
			for (int j = row + 1; j < board.length; j++) {
				// checking row
				if (board[row] == board[j]) {
					currCost++;
				}
				// check upper diagonal
				else if (board[row] == board[j] + j - row) {
					currCost++;
				}
				// check lower diagonal
				else if (board[row] == board[j] - (j - row)) {
					currCost++;
				}
			}
		}
		return currCost;
	}
}

public class EightQueen {
	public static void main(String args[]) {
		if (args.length != 2 && args.length != 3) {
			System.out.println("Invalid Number of Input Arguments");
			return;
		}

		int flag = Integer.valueOf(args[0]);
		int option = flag / 100;
		int iteration = flag % 100;
		char[] board = new char[8];
		int seed = -1;
		int board_index = -1;

		if (args.length == 2 && (option == 1 || option == 2 || option == 4)) {
			board_index = 1;
		} else if (args.length == 3 && (option == 3 || option == 5)) {
			seed = Integer.valueOf(args[1]);
			board_index = 2;
		} else {
			System.out.println("Invalid Number of Input Arguments");
			return;
		}

		if (board_index == -1)
			return;
		for (int i = 0; i < 8; i++) {
			board[i] = args[board_index].charAt(i);
			int pos = board[i] - '0';
			if (pos < 0 || pos > 7) {
				System.out.println("Invalid input: queen position(s)");
				return;
			}
		}

		State init = new State(board);
		init.printState(option, iteration, seed);
	}
}