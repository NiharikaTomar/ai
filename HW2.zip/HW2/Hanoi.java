import java.util.*;

////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW2 Hanoi.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Due date: februray 21 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
 * This class aims to test the Towers of Hanoi propmpt given in HW2. Consists of
 * variety of conditions to ensure proper working of program
 * 
 * @author niharikatomar
 */

public class Hanoi {

	public static List<String> getSuccessor(String[] hanoi) {

		// Checking each rod, to see what can be moved and then storing it in a new
		// array temp

		List<String> result = new ArrayList<>(); // result to be returned

		String[] temp = new String[hanoi.length];
		String[] aux = new String[hanoi.length];
		String tempResult = "";
		boolean lcheck = false;

		for (int i = 0; i < hanoi.length; i++) { // loop for every possible move
			// Resetting temp with hanoi for a next value check
			for (int j = 0; j < hanoi.length; j++) {
				temp[j] = hanoi[j];
			}
			tempResult = "";

			// Checking to see if there is any action required to do for current state
			if (!temp[i].equals("0")) {
				aux = hanoi[i].split(""); // Splitting the rod into separate string values
				if (i == 0) { // check left rod
					if (temp[i + 1].equals("0")) { // If the next rod is empty
						temp[i + 1] = aux[0]; // transfer disc from left rod to current
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // getting temporary result value stored previously and
																// updating it
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}

					// If the left rod is not empty, check if top disc greater than other rod's top
					// disc
					if (temp[i + 1].compareTo(aux[0]) > 0) {
						temp[i + 1] = aux[0] + temp[i + 1];
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}
				}

				// Checking rod(s) in center
				if (i > 0 && i < hanoi.length - 1) {
					if (hanoi[i - 1].equals("0") && !lcheck) { // If left of the current rod is empty
						temp[i - 1] = aux[0]; // Put the disc from the right rod onto current rod
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						i--; // checking next
						lcheck = true; // updating value of the left check
						continue; // continue
					}

					// If the rod is not empty, check if top disc greater than other rod's top disc
					if (temp[i - 1].substring(0, 1).compareTo(aux[0]) > 0 && !lcheck) {
						if (temp[i - 1].equals("0")) {
							temp[i - 1] = aux[0];
						} else {
							temp[i - 1] = aux[0] + temp[i - 1];
						}
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						i--; // checking next
						lcheck = true; // updating value of the left check
						continue; // continue
					}

					lcheck = false; // updating value of the left check if no condition above executed
					if (hanoi[i + 1].equals("0")) {
						temp[i + 1] = aux[0]; // Put the disc from the left rod onto current rod
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}

					// If letf rod has something, check to see if greater
					if (temp[i + 1].compareTo(aux[0]) > 0) {
						temp[i + 1] = aux[0]; // Put the disc from the left rod onto current rod
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}
				}

				// Checking the last rod
				if (i == hanoi.length - 1) {
					if (hanoi[hanoi.length - 2].equals("0")) {
						temp[i - 1] = aux[0]; // Put the disc from the this rod onto current rod
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1]; // updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}

					if (temp[i - 1].compareTo(aux[0]) > 0) {
						temp[i - 1] = aux[0]; // Put the disc from the this rod onto current rod
						if (temp[i].length() > 1) { // if discs present
							temp[i] = temp[i].substring(1); // getting top disc
						} else {
							temp[i] = "0"; // if nothing left on rod put 0
						}
						for (int j = 0; j < temp.length - 1; j++) {
							tempResult = tempResult + temp[j] + " "; // storing temporary result in tempResult
						}
						tempResult += temp[temp.length - 1];// updating temporary result value stored previously
						result.add(tempResult); // adding temporary result to final result
						continue; // continue
					}
				}
			}
		}
		return result; // returning final result
	}

	public static void main(String[] args) {
		if (args.length < 3) {
			return;
		}

		List<String> sucessors = getSuccessor(args);
		for (int i = 0; i < sucessors.size(); i++) {
			System.out.println(sucessors.get(i));
		}
	}
}