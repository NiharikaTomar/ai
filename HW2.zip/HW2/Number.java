import java.util.*;
////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW2 Number.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Due date: februray 21 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
* This class aims to test the Number prompt given in HW2. Consists of
* variety of conditions to ensure proper working of program
* 
* @author niharikatomar
*/
class Node { // class node containing value and steps to be updated later
	int value;
	int steps;

	public Node(int value, int steps) { //constructor updating value an steps
		this.value = value;
		this.steps = steps;
	}
}

public class Number {
	public static String getStep(int x, int y) {
		String result = ""; //result to be returned and updated
		HashSet<Integer> visited = new HashSet<>(); // making a hash set to keep track of visited nodes
		ArrayDeque<Node> queue = new ArrayDeque<Node>();// making a queue for BFS approach

		Node node = new Node(x, 0); //if final value 0, 
		queue.offer(node); // dequeue the node 
		
		while (!queue.isEmpty()) { //if queue is not empty
			Node temp = queue.poll();  // dequeue the node 
			visited.add(temp.value); //and add the node to visited node track

			if (temp.value == y) { // if final value reached
				result = "" + temp.steps; //store result
				break; //and exit loop
			}

			int firstOp = temp.value + 1; //first possible operation to be performed
			int secondOp = temp.value - 1; //second possible operation to be performed
			int thirdOp = temp.value * 3; //third possible operation to be performed
			int fourthOp = temp.value * temp.value; //fourth possible operation to be performed

			// checking for given constraints
			//first operation check
			if (firstOp > 0 && firstOp < 100 && !visited.contains(firstOp)) { //limit 0<x,y<100
				Node nodeFirstOp = new Node(firstOp, temp.steps + 1); //incrementing steps
				queue.offer(nodeFirstOp); //remove node
			}
			//second operation check
			if (secondOp > 0 && secondOp < 100 && !visited.contains(secondOp)) { //limit 0<x,y<100
				Node nodeSecondOp = new Node(secondOp, temp.steps + 1);
				queue.offer(nodeSecondOp); //remove node
			}
			//third operation check
			if (thirdOp > 0 && thirdOp < 100 && !visited.contains(thirdOp)) { //limit 0<x,y<100
				Node nodeThirdOp = new Node(thirdOp, temp.steps + 1); //incrementing steps
				queue.offer(nodeThirdOp); //remove node
			}
			//fourth operation check
			if (fourthOp > 0 && fourthOp < 100 && !visited.contains(fourthOp)) { //limit 0<x,y<100
				Node nodeFourthOp = new Node(fourthOp, temp.steps + 1);//incrementing steps
				queue.offer(nodeFourthOp); //remove node
			}
		}
		return result; //return final result
	}

	public static void main(String[] args) {
		if (args.length != 2) {
			return;
		}
		System.out.println(getStep(Integer.parseInt(args[0]), Integer.parseInt(args[1])));
	}
}