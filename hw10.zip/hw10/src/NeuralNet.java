////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW10 NeuralNet.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
* This class aims to implement the NeuralNet prompt given in HW10. Consists of
* variety of conditions to ensure proper working of the program.
* 
* @author niharikatomar
*/
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class NeuralNet {

	private static double sigmoid(double x) {
		return (1 / (1 + Math.pow(Math.E, (-1 * x))));
	}

	private static ArrayList<Double> getInput(ArrayList<Double> w) {
		ArrayList<Double> edt = new ArrayList<Double>();
		edt.add(1.0);
		edt.add(w.get(13));
		edt.add(w.get(14));
		edt.add(w.get(15));
		edt.add(w.get(16));
		return edt;
	}

	private static ArrayList<Double> layer1(ArrayList<Double> w) {
		ArrayList<Double> edt = new ArrayList<Double>();
		edt.add(w.get(0));
		edt.add(w.get(1));
		edt.add(w.get(2));
		edt.add(w.get(3));
		edt.add(w.get(4));
		return edt;
	}

	private static ArrayList<Double> layer2(ArrayList<Double> w) {
		ArrayList<Double> edt = new ArrayList<Double>();
		edt.add(w.get(5));
		edt.add(w.get(6));
		edt.add(w.get(7));
		edt.add(w.get(8));
		edt.add(w.get(9));
		return edt;
	}

	private static ArrayList<Double> layer3(ArrayList<Double> w) {
		ArrayList<Double> edt = new ArrayList<Double>();
		edt.add(w.get(10));
		edt.add(w.get(11));
		edt.add(w.get(12));
		return edt;
	}

	private static void getResult(ArrayList<Double> editedWeight) {
		for (int j = 0; j < editedWeight.size(); j++) {
			System.out.printf("%.5f", editedWeight.get(j));
			if (j == editedWeight.size() - 1) {
				System.out.println();
			} else {
				System.out.print(" ");
			}
		}

	}

	public static void calcFlagOutput(String flag, ArrayList<ArrayList<Double>> x, ArrayList<Integer> y,
			ArrayList<Double> w, ArrayList<ArrayList<Double>> xEval, ArrayList<Integer> yEval,
			ArrayList<ArrayList<Double>> xTest, ArrayList<Integer> yTest) {
		/**
		 * @param: aij
		 *             = activation of layer i node j
		 * @param: sij
		 *             = backward propagating term of layer i node j
		 * @param: temp
		 *             = an ArrayList collecting all the weight correction term in
		 *             layer-node order(i.e.(1,0),(1,1)...(2,0),(2,1)..)
		 *
		 **/
		if (flag.equals("100")) {
			double sum = 0.0;
			ArrayList<Double> inputLayer = getInput(w);
			ArrayList<Double> weightOfNode1 = layer1(w);
			ArrayList<Double> weightOfNode2 = layer2(w);
			ArrayList<Double> weightOfNode3 = layer3(w);

			for (int i = 0; i < inputLayer.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode1.get(i);
			}
			double a21 = sigmoid(sum);
			sum = 0.0;
			for (int i = 0; i < weightOfNode2.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode2.get(i);
			}
			double a22 = sigmoid(sum);
			sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
			double a31 = sigmoid(sum);

			// output
			System.out.printf("%.5f", a21);
			System.out.print(" ");
			System.out.printf("%.5f", a22);
			System.out.println();
			System.out.printf("%.5f", a31);
			System.out.println();
		} else if (flag.equals("200")) {
			double sum = 0.0;
			ArrayList<Double> inputLayer = getInput(w);
			ArrayList<Double> weightOfNode1 = layer1(w);
			ArrayList<Double> weightOfNode2 = layer2(w);
			ArrayList<Double> weightOfNode3 = layer3(w);

			for (int i = 0; i < inputLayer.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode1.get(i);
			}
			double a21 = sigmoid(sum);
			sum = 0.0;
			for (int i = 0; i < weightOfNode2.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode2.get(i);
			}
			double a22 = sigmoid(sum);
			sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
			double a31 = sigmoid(sum);
			double sigmoid31 = (a31 - w.get(17)) * a31 * (1 - a31);
			System.out.printf("%.5f", sigmoid31);
			System.out.println();
		} else if (flag.equals("300")) {
			double sum = 0.0;
			ArrayList<Double> inputLayer = getInput(w);
			ArrayList<Double> weightOfNode1 = layer1(w);
			ArrayList<Double> weightOfNode2 = layer2(w);
			ArrayList<Double> weightOfNode3 = layer3(w);

			for (int i = 0; i < inputLayer.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode1.get(i);
			}
			double a21 = sigmoid(sum);
			sum = 0.0;
			for (int i = 0; i < weightOfNode1.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode2.get(i);
			}
			double a22 = sigmoid(sum);
			sum =  a22 * weightOfNode3.get(2) + a21 * weightOfNode3.get(1) + 1 * weightOfNode3.get(0);
			double a31 = sigmoid(sum);
			double sigmoid31 = (a31 - w.get(17)) * a31 * (1 - a31);
			double sigmoid21 = sigmoid31 * weightOfNode3.get(1) * a21 * (1 - a21);
			double sigmoid22 = sigmoid31 * weightOfNode3.get(2) * a22 * (1 - a22);
			System.out.printf("%.5f", sigmoid21);
			System.out.print(" ");
			System.out.printf("%.5f", sigmoid22);
			System.out.println();

		} else if (flag.equals("400")) {
			double sum = 0.0;
			ArrayList<Double> inputLayer = getInput(w);
			ArrayList<Double> weightOfNode1 = layer1(w);
			ArrayList<Double> weightOfNode2 = layer2(w);
			ArrayList<Double> weightOfNode3 = layer3(w);
			ArrayList<Double> temp = new ArrayList<Double>();

			for (int i = 0; i < inputLayer.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode1.get(i);
			}

			double a21 = sigmoid(sum);
			sum = 0.0;
			for (int i = 0; i < weightOfNode1.size(); i++) {
				sum += inputLayer.get(i) * weightOfNode2.get(i);
			}
			double a22 = sigmoid(sum);
			sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
			double a31 = sigmoid(sum);
			double sigmoid31 = (a31 - w.get(17)) * a31 * (1 - a31);
			double sigmoid21 = sigmoid31 * weightOfNode3.get(1) * a21 * (1 - a21);
			double sigmoid22 = sigmoid31 * weightOfNode3.get(2) * a22 * (1 - a22);
			int j = 0;
			for (int i = 0; i < 10; i++) {
				if (i < 5) {
					temp.add(sigmoid21 * inputLayer.get(i));
				} else if (i <= 10) {
					j = i - 5;
					temp.add(sigmoid22 * inputLayer.get(j));
				}
			}
			temp.add(sigmoid31 * 1);
			temp.add(sigmoid31 * a21);
			temp.add(sigmoid31 * a22);

			// resulting output
			System.out.printf("%.5f", temp.get(temp.size() - 3));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(temp.size() - 2));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(temp.size() - 1));
			System.out.println();
			System.out.printf("%.5f", temp.get(0));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(1));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(2));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(3));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(4));
			System.out.println();
			System.out.printf("%.5f", temp.get(5));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(6));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(7));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(8));
			System.out.print(" ");
			System.out.printf("%.5f", temp.get(9));
			System.out.println();

		} else if (flag.equals("500")) {
			ArrayList<Double> editedWeight = new ArrayList<Double>();
			for (int i = 0; i < w.size() - 1; i++) {
				editedWeight.add(w.get(i));
			}
			double eta = w.get(13);
			for (int i = 0; i < x.size(); i++) {
				double sum = 0.0;
				ArrayList<Double> weightOfNode1 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode2 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode3 = new ArrayList<Double>();
				for (int j = 0; j < 13; j++) {
					if (j < 5) {
						weightOfNode1.add(editedWeight.get(j));
					} else if (j < 10) {
						weightOfNode2.add(editedWeight.get(j));
					} else {
						weightOfNode3.add(editedWeight.get(j));
					}
				}
				ArrayList<Double> inputLayer = x.get(i);
				for (int j = 0; j < inputLayer.size(); j++) {
					sum += inputLayer.get(j) * weightOfNode1.get(j);
				}
				double a21 = sigmoid(sum);
				sum = 0.0;
				for (int j = 0; j < weightOfNode2.size(); j++) {
					sum += inputLayer.get(j) * weightOfNode2.get(j);
				}
				double a22 = sigmoid(sum);
				sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
				double a31 = sigmoid(sum);
				double sigmoid31 = (a31 - y.get(i)) * a31 * (1 - a31);
				double sigmoid21 = sigmoid31 * weightOfNode3.get(1) * a21 * (1 - a21);
				double sigmoid22 = sigmoid31 * weightOfNode3.get(2) * a22 * (1 - a22);
				ArrayList<Double> temp = new ArrayList<Double>();
				for (int j = 0; j < 10; j++) {
					if (j < 5) {
						temp.add(sigmoid21 * inputLayer.get(j));
					} else if (j < 10) {
						int n = 0;
						n = j - 5;
						temp.add(sigmoid22 * inputLayer.get(n));
					}
				}
				temp.add(sigmoid31 * 1);
				temp.add(sigmoid31 * a21);
				temp.add(sigmoid31 * a22);
				for (int t = 0; t < temp.size(); t++) {
					double edit = eta * temp.get(t);
					editedWeight.set(t, editedWeight.get(t) - edit);
				}

				double Eeval = 0.0;
				for (int j = 0; j < xEval.size(); j++) {
					sum = 0.0;
					weightOfNode1 = new ArrayList<Double>();
					weightOfNode2 = new ArrayList<Double>();
					weightOfNode3 = new ArrayList<Double>();
					for (int n = 0; n < 13; n++) {
						if (n < 5) {
							weightOfNode1.add(editedWeight.get(n));
						} else if (n < 10) {
							weightOfNode2.add(editedWeight.get(n));
						} else {
							weightOfNode3.add(editedWeight.get(n));
						}
					}
					inputLayer = xEval.get(j);

					for (int k = 0; k < inputLayer.size(); k++) {
						sum += inputLayer.get(k) * weightOfNode1.get(k);
					}
					a21 = sigmoid(sum);
					sum = 0.0;
					for (int n = 0; n < weightOfNode2.size(); n++) {
						sum += inputLayer.get(n) * weightOfNode2.get(n);
					}
					a22 = sigmoid(sum);
					sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
					a31 = sigmoid(sum);
					double Ex = 0.5 * (a31 - yEval.get(j)) * (a31 - yEval.get(j));
					Eeval = Eeval + Ex;
				}

				// resulting output
				getResult(editedWeight);
				System.out.printf("%.5f", Eeval);
				if (i != x.size() - 1) {
					System.out.println();
				}

			}
			System.out.println();
		} else if (flag.equals("600")) {
			ArrayList<Double> editedWeight = new ArrayList<Double>();
			for (int i = 0; i < w.size() - 1; i++) {
				editedWeight.add(w.get(i));
			}
			double eta = w.get(13);
			for (int i = 0; i < x.size(); i++) {
				double sum = 0.0;
				ArrayList<Double> weightOfNode1 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode2 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode3 = new ArrayList<Double>();
				for (int j = 0; j < 13; j++) {
					if (j < 5) {
						weightOfNode1.add(editedWeight.get(j));
					} else if (j < 10) {
						weightOfNode2.add(editedWeight.get(j));
					} else {
						weightOfNode3.add(editedWeight.get(j));
					}
				}
				ArrayList<Double> inputLayer = x.get(i);
				for (int j = 0; j < inputLayer.size(); j++) {
					sum += inputLayer.get(j) * weightOfNode1.get(j);
				}
				double a21 = sigmoid(sum);
				sum = 0.0;
				for (int j = 0; j < weightOfNode2.size(); j++) {
					sum += inputLayer.get(j) * weightOfNode2.get(j);
				}
				double a22 = sigmoid(sum);
				sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
				double a31 = sigmoid(sum);
				double sigmoid31 = (a31 - y.get(i)) * a31 * (1 - a31);
				double sigmoid21 = sigmoid31 * weightOfNode3.get(1) * a21 * (1 - a21);
				double sigmoid22 = sigmoid31 * weightOfNode3.get(2) * a22 * (1 - a22);

				ArrayList<Double> temp = new ArrayList<Double>();
				for (int j = 0; j < 10; j++) {
					if (j < 5) {
						temp.add(sigmoid21 * inputLayer.get(j));
					} else if (j < 10) {
						int n = 0;
						n = j - 5;
						temp.add(sigmoid22 * inputLayer.get(n));
					}
				}
				temp.add(sigmoid31 * 1);
				temp.add(sigmoid31 * a21);
				temp.add(sigmoid31 * a22);
				for (int j = 0; j < temp.size(); j++) {
					double edit = eta * temp.get(j);
					editedWeight.set(j, editedWeight.get(j) - edit);
				}
			}
			int actual = 0;
			for (int i = 0; i < xTest.size(); i++) {
				double sum = 0.0;
				ArrayList<Double> weightOfNode1 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode2 = new ArrayList<Double>();
				ArrayList<Double> weightOfNode3 = new ArrayList<Double>();
				for (int n = 0; n < 13; n++) {
					if (n < 5) {
						weightOfNode1.add(editedWeight.get(n));
					} else if (n < 10) {
						weightOfNode2.add(editedWeight.get(n));
					} else {
						weightOfNode3.add(editedWeight.get(n));
					}
				}

				ArrayList<Double> inputLayer = xTest.get(i);
				for (int n = 0; n < inputLayer.size(); n++) {
					sum += inputLayer.get(n) * weightOfNode1.get(n);
				}

				double a21 = sigmoid(sum);
				sum = 0.0;
				for (int n = 0; n < weightOfNode2.size(); n++) {
					sum += inputLayer.get(n) * weightOfNode2.get(n);
				}
				double a22 = sigmoid(sum);

				sum = 1 * weightOfNode3.get(0) + a21 * weightOfNode3.get(1) + a22 * weightOfNode3.get(2);
				double a31 = sigmoid(sum);

				int expected = 0;
				if (a31 <= 0.5) {
					expected = 0;
				} else {
					expected = 1;
				}
				if (expected == yTest.get(i)) {
					actual += 1;
				}

				// outputting the result
				System.out.printf("%d", yTest.get(i));
				System.out.print(" ");
				System.out.printf("%d", expected);
				System.out.print(" ");
				System.out.printf("%.5f", a31);
				System.out.println();
			}
			double accuracy = (double) actual / xTest.size();
			System.out.printf("%.2f", accuracy);
			System.out.println();
		}
	}

	public static void main(String args[]) throws FileNotFoundException, IOException {

		// parsing args
		ArrayList<Double> w = new ArrayList<Double>();
		for (int i = 1; i < args.length; i++) {
			w.add(Double.valueOf(args[i]));
		}
		String flag = args[0];

		// reading data
		BufferedReader readTraining = new BufferedReader(
				new FileReader("train.csv"));

		ArrayList<ArrayList<Double>> x = new ArrayList<ArrayList<Double>>();
		ArrayList<Integer> y = new ArrayList<Integer>();

		String line;

		// getting all training data
		while ((line = readTraining.readLine()) != null) {
			String[] values = line.split(",");
			ArrayList<Double> xbr = new ArrayList<Double>();
			ArrayList<Double> brStruct = new ArrayList<Double>();
			for (int i = 0; i < values.length; i++) {
				xbr.add(Double.valueOf(values[i]));
			}
			// re-organizing data
			for (int i = 0; i < xbr.size(); i++) {
				if (i == 0) {
					brStruct.add(1.0);
				} else {
					brStruct.add(xbr.get(i - 1));
				}
			}
			x.add(brStruct);
			y.add(Integer.parseInt(values[4]));
		}

		// getting all evaluating data
		ArrayList<ArrayList<Double>> xEval = new ArrayList<ArrayList<Double>>();
		ArrayList<Integer> yEval = new ArrayList<Integer>();
		BufferedReader readEvaluating = new BufferedReader(
				new FileReader("eval.csv"));
		while ((line = readEvaluating.readLine()) != null) {
			String[] values = line.split(",");
			ArrayList<Double> xbr = new ArrayList<Double>();
			ArrayList<Double> brStruct = new ArrayList<Double>();
			for (int i = 0; i < values.length; i++) {
				xbr.add(Double.valueOf(values[i]));
			}
			// re-organize data
			for (int i = 0; i < xbr.size(); i++) {
				if (i == 0) {
					brStruct.add(1.0);
				} else {
					brStruct.add(xbr.get(i - 1));
				}
			}
			xEval.add(brStruct);
			yEval.add(Integer.parseInt(values[4]));
		}

		// get all testing data
		ArrayList<ArrayList<Double>> xTest = new ArrayList<ArrayList<Double>>();
		ArrayList<Integer> yTest = new ArrayList<Integer>();
		BufferedReader readTest = new BufferedReader(
				new FileReader("test.csv"));
		while ((line = readTest.readLine()) != null) {
			String[] values = line.split(",");
			ArrayList<Double> xbr = new ArrayList<Double>();
			ArrayList<Double> brStruct = new ArrayList<Double>();
			for (int i = 0; i < values.length; i++) {
				xbr.add(Double.valueOf(values[i]));
			}
			// re-organize data
			for (int i = 0; i < xbr.size(); i++) {
				if (i == 0) {
					brStruct.add(1.0);
				} else {
					brStruct.add(xbr.get(i - 1));
				}
			}
			xTest.add(brStruct);
			yTest.add(Integer.parseInt(values[4]));
		}
		calcFlagOutput(flag, x, y, w, xEval, yEval, xTest, yTest);
		readTest.close();
		readEvaluating.close();
		readTraining.close();
	}

}
