////////////////////ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
//Title: HW7 Chatbot.java
//Course and lecture: CS 540 lecture 001, Spring 2019
//Author: Niharika Tomar
//Email: ntomar@wisc.edu
//Lecturer's Name: Yingyu Liang
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
//Students who get help from sources other than their partner must fully
//acknowledge and credit those sources of help here. Instructors and TAs do
//not need to be credited here, but tutors, friends, relatives, room mates,
//strangers, and others do. If you received no outside help from either type
//of source, then please explicitly indicate NONE.
//
//Persons: (identify each person and describe their help in detail)
//Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 100 COLUMNS WIDE ///////////////////////////////
/**
 * This class aims to implement the Chatbot prompt given in HW7. Consists of
 * variety of conditions to ensure proper working of the program.
 * 
 * @author niharikatomar
 */

import java.util.*;
import java.io.*;

public class Chatbot {
	private static String filename = "./corpus.txt";

	private static ArrayList<Integer> readCorpus() {
		ArrayList<Integer> corpus = new ArrayList<Integer>();
		try {
			File f = new File(filename);
			Scanner sc = new Scanner(f);
			while (sc.hasNext()) {
				if (sc.hasNextInt()) {
					int i = sc.nextInt();
					corpus.add(i);
				} else {
					sc.next();
				}
			}
		} catch (FileNotFoundException ex) {
			System.out.println("File Not Found.");
		}
		return corpus;
	}

	/**
	 * This class helps with the implementation of the random sampling from a
	 * probability distribution.
	 */
	private static class SegmentOfWord {
		public final int word;
		public final double left;
		public final double right;

		public SegmentOfWord(int word, double left, double right) {
			this.word = word;
			this.left = left;
			this.right = right;
		}
	}

	/**
	 * Gets the probability intervals by adding each probability individually.
	 * 
	 */
	private static SegmentOfWord[] getProbabilityIntervals(HashMap<Integer, Double> probabilities, int numOfWordtypes) {

		SegmentOfWord[] segments = new SegmentOfWord[probabilities.size()];
		int i = 0; // used to increment segments array when getting probability intervals

		// for iterating through wordtypes
		for (int word = 0; word < numOfWordtypes; word++) {
			if (probabilities.containsKey(word)) {

				double probability = probabilities.get(word);
				// adds probability to interval (l,r]
				if (i != 0) {
					segments[i] = new SegmentOfWord(word, segments[i - 1].right, segments[i - 1].right + probability);
				} else {
					// Segment 0 is [l0 = 0, r0 = p0].
					segments[i] = new SegmentOfWord(word, 0.0, probability);
				}
				i++; // increments segments array
			}
		}
		return segments;
	}

	static public void main(String[] args) {
		ArrayList<Integer> corpus = readCorpus();
		int flag = Integer.valueOf(args[0]);

		int numOfWordtypes = 0; // count for the number of word types
		for (int i : corpus) {
			if (i > numOfWordtypes) {
				numOfWordtypes = i;
			}
		}
		numOfWordtypes++; // counts for OOV

		if (flag == 100) {
			int w = Integer.valueOf(args[1]);
			int count = 0;
			// TODO count occurence of w
			for (int i : corpus) {
				if (w == i) {
					count++;
				}
			}
			System.out.println(count);
			System.out.println(String.format("%.7f", (count + 1) / (double) (corpus.size() + 4700)));
		} else if (flag == 200) {
			int n1 = Integer.valueOf(args[1]);
			int n2 = Integer.valueOf(args[2]);
			// TODO generate
			double r = (double) n1 / n2;
			// hashmap stores the wordtype and count occurrence of the word type
			HashMap<Integer, Integer> countsOfWordtypes = new HashMap<>();
			for (int word : corpus) {
				countsOfWordtypes.put(word, countsOfWordtypes.getOrDefault(word, 0) + 1);
			}

			// hashmap stores wordtype and the probability from flag 100 inside
			HashMap<Integer, Double> probabilitiesOfWordtypes = new HashMap<>();
			for (Integer wordtype : countsOfWordtypes.keySet()) {
				probabilitiesOfWordtypes.put((wordtype),
						(double) (countsOfWordtypes.get(wordtype) + 1) / (corpus.size() + 4700));
			}

			SegmentOfWord[] segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

			if (r == 0) {
				System.out.println(segments[0].word);
				System.out.printf("%.7f\n", segments[0].left);
				System.out.printf("%.7f\n", segments[0].right);
				return;
			}
			for (SegmentOfWord segment : segments) {
				if (r > segment.left && r <= segment.right) {
					System.out.println(segment.word);
					System.out.printf("%.7f\n", segment.left);
					System.out.printf("%.7f\n", segment.right);
					return;
				}
			}

		} else if (flag == 300) {
			int h = Integer.valueOf(args[1]);
			int w = Integer.valueOf(args[2]);
			int count = 0;
			int vLeng = 4700;
			ArrayList<Integer> words_after_h = new ArrayList<Integer>();

			// TODO
			// For bigrams, history stops at the 2nd to last word position in the corpus
			for (int i = 0; i < corpus.size() - 1; i++) {
				// indexes to a wordtype of h
				if (corpus.get(i).equals(h)) {
					// adds next wordtype after c(h, u)
					words_after_h.add(corpus.get(i + 1));

					if (corpus.get(i + 1) == w) {
						count++;
					}
				}
			}

			// output
			System.out.println(count);
			System.out.println(words_after_h.size());
			System.out.println(String.format("%.7f", (count + 1) / (double) (words_after_h.size() + 4700)));
		} else if (flag == 400) {
			int n1 = Integer.valueOf(args[1]);
			int n2 = Integer.valueOf(args[2]);
			int h = Integer.valueOf(args[3]);
			// TODO
			double r = (double) n1 / n2;
			int words_after_h = 0;
			ArrayList<Integer> voc = new ArrayList<Integer>();
			HashMap<Integer, Integer> countsOfWordtypes = new HashMap<>();
			for (int i = 0; i < corpus.size(); i++) {
				if (!voc.contains(corpus.get(i))) {
					voc.add(corpus.get(i));
				}
			}

			for (int i = 0; i < voc.size(); i++) {
				countsOfWordtypes.put(i, 1);
			}

			// hashmap stores the wordtype and count occurrence of the word type

			for (int i = 0; i < corpus.size() - 1; i++) {
				if (corpus.get(i).equals(h)) {
					words_after_h++;
					// puts the count after h into the count occurrence
					countsOfWordtypes.put(corpus.get(i + 1), countsOfWordtypes.getOrDefault(corpus.get(i + 1), 0) + 1);
				}
			}
			// hashmap stores wordtype and the probability from flag 100 inside
			HashMap<Integer, Double> probabilitiesOfWordtypes = new HashMap<>();
			double sum = 0;
			for (Integer wordtype : countsOfWordtypes.keySet()) {
				probabilitiesOfWordtypes.put(wordtype,
						(double) (countsOfWordtypes.get(wordtype)) / (words_after_h + 4700));
				sum = sum + probabilitiesOfWordtypes.get(wordtype);
			}

			SegmentOfWord[] segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);
			if (r == 0) {
				System.out.println(segments[0].word);
				System.out.printf("%.7f\n", segments[0].left);
				System.out.printf("%.7f\n", segments[0].right);
				return;
			}
			for (SegmentOfWord segment : segments) {
				if (r > segment.left && r <= segment.right) {
					System.out.println(segment.word);
					System.out.printf("%.7f\n", segment.left);
					System.out.printf("%.7f\n", segment.right);
					return;
				}
			}

		} else if (flag == 500) {
			int h1 = Integer.valueOf(args[1]);
			int h2 = Integer.valueOf(args[2]);
			int w = Integer.valueOf(args[3]);
			int count = 0;
			ArrayList<Integer> words_after_h1h2 = new ArrayList<Integer>();
			// TODO
			// we got to index 2 spots ahead for trigram so corpus.size() - 2 is correct
			// here not -1.
			for (int i = 0; i < corpus.size() - 2; i++) {
				if (corpus.get(i).equals(h1) && corpus.get(i + 1).equals(h2)) {

					words_after_h1h2.add(corpus.get(i + 2));

					if (corpus.get(i + 2) == w) {
						count++;
					}
				}
			}

			// output
			System.out.println(count);
			System.out.println(words_after_h1h2.size());
			if ((words_after_h1h2.size() + 1) == 0)
				System.out.println("undefined");
			else
				System.out.println(String.format("%.7f", (count + 1) / (double) (words_after_h1h2.size() + 4700)));
		} else if (flag == 600) {
			int n1 = Integer.valueOf(args[1]);
			int n2 = Integer.valueOf(args[2]);
			int h1 = Integer.valueOf(args[3]);
			int h2 = Integer.valueOf(args[4]);
			// TODO

			double r = (double) n1 / n2;
			int words_after_h1h2 = 0;
			ArrayList<Integer> voc = new ArrayList<Integer>();
			// hashmap stores the wordtype and count occurrence of the word type
			HashMap<Integer, Integer> countsOfWordtypes = new HashMap<>();
			for (int i = 0; i < corpus.size(); i++) {
				if (!voc.contains(corpus.get(i))) {
					voc.add(corpus.get(i));
				}
			}

			for (int i = 0; i < voc.size(); i++) {
				countsOfWordtypes.put(i, 1);
			}

			for (int i = 0; i < corpus.size() - 2; i++) {
				if (corpus.get(i).equals(h1) && corpus.get(i + 1).equals(h2)) {
					words_after_h1h2++;
					// puts the count after h1h2 into the count occurrence
					countsOfWordtypes.put(corpus.get(i + 2), countsOfWordtypes.getOrDefault(corpus.get(i + 2), 0) + 1);
				}
			}

			if ((words_after_h1h2+1) == 0) {
				System.out.println("undefined");
				return;
			}
			// hashmap stores wordtype and the probability from flag 100 inside
			HashMap<Integer, Double> probabilitiesOfWordtypes = new HashMap<>();
			for (Integer wordtype : countsOfWordtypes.keySet()) {
				probabilitiesOfWordtypes.put(wordtype,
						(double) countsOfWordtypes.get(wordtype) / (words_after_h1h2 + 4700));
			}

			SegmentOfWord[] segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

			if (r == 0) {
				System.out.println(segments[0].word);
				System.out.printf("%.7f\n", segments[0].left);
				System.out.printf("%.7f\n", segments[0].right);
				return;
			}
			for (SegmentOfWord segment : segments) {
				if (r > segment.left && r <= segment.right) {
					System.out.println(segment.word);
					System.out.printf("%.7f\n", segment.left);
					System.out.printf("%.7f\n", segment.right);
					return;
				}
			}
		} else if (flag == 700) {
			int seed = Integer.valueOf(args[1]);
			int t = Integer.valueOf(args[2]);
			int h1 = 0, h2 = 0;

			HashMap<Integer, Integer> countsOfWordtypes = new HashMap<>();
			HashMap<Integer, Double> probabilitiesOfWordtypes;
			ArrayList<Integer> voc = new ArrayList<Integer>();
			SegmentOfWord[] segments;

			Random rng = new Random();
			if (seed != -1) {
				rng.setSeed(seed);
			}

			for (int i = 0; i < corpus.size(); i++) {
				if (!voc.contains(corpus.get(i))) {
					voc.add(corpus.get(i));
				}
			}

			for (int i = 0; i < voc.size(); i++) {
				countsOfWordtypes.put(i, 1);
			}

			if (t == 0) {
				// TODO Generate first word using r
				double r = rng.nextDouble();

				// hashmap stores the wordtype and count occurrence of the word type
				// countsOfWordtypes = new HashMap<>();
				for (int word : corpus) {
					countsOfWordtypes.put(word, countsOfWordtypes.getOrDefault(word, 0) + 1);
				}

				// hashmap stores wordtype and the probability from flag 100 inside
				probabilitiesOfWordtypes = new HashMap<>();
				for (Integer wordtype : countsOfWordtypes.keySet()) {
					probabilitiesOfWordtypes.put(wordtype,
							(double) (countsOfWordtypes.get(wordtype)) / (corpus.size() + 4700));
				}

				segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

				if (r == 0) {
					h1 = segments[0].word;
				}
				for (SegmentOfWord segment : segments) {
					if (r > segment.left && r <= segment.right) {
						h1 = segment.word;
					}
				}

				System.out.println(h1);
				if (h1 == 9 || h1 == 10 || h1 == 12) {
					return;
				}

				// TODO Generate second word using r
				r = rng.nextDouble();
				int words_after_h = 0;

				// hashmap stores the wordtype and count occurrence of the word type
				// countsOfWordtypes = new HashMap<>();
				for (int i = 0; i < voc.size(); i++) {
					countsOfWordtypes.put(i, 1);
				}
				for (int i = 0; i < corpus.size() - 1; i++) {
					if (corpus.get(i).equals(h1)) {
						words_after_h++;
						// puts the count after h into the count occurrence
						countsOfWordtypes.put(corpus.get(i + 1),
								countsOfWordtypes.getOrDefault(corpus.get(i + 1), 0) + 1);
					}
				}
				// hashmap stores wordtype and the probability from flag 100 inside
				probabilitiesOfWordtypes = new HashMap<>();
				for (Integer wordtype : countsOfWordtypes.keySet()) {
					probabilitiesOfWordtypes.put(wordtype,
							(double) countsOfWordtypes.get(wordtype) / (words_after_h + 4700));
				}

				segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

				if (r == 0) {
					h2 = segments[0].word;
				}
				for (SegmentOfWord segment : segments) {
					if (r > segment.left && r <= segment.right) {
						h2 = segment.word;
					}
				}

				System.out.println(h2);
			}

			else if (t == 1) {
				h1 = Integer.valueOf(args[3]);
				// TODO Generate second word using r
				double r = rng.nextDouble();
				int words_after_h = 0;

				// hashmap stores the wordtype and count occurrence of the word type
				// countsOfWordtypes = new HashMap<>();
				for (int i = 0; i < corpus.size() - 1; i++) {
					if (corpus.get(i).equals(h1)) {
						words_after_h++;
						// puts the count after h into the count occurrence
						countsOfWordtypes.put(corpus.get(i + 1),
								countsOfWordtypes.getOrDefault(corpus.get(i + 1), 0) + 1);
					}
				}
				// hashmap stores wordtype and the probability from flag 100 inside
				probabilitiesOfWordtypes = new HashMap<>();
				for (Integer wordtype : countsOfWordtypes.keySet()) {
					probabilitiesOfWordtypes.put(wordtype,
							(double) countsOfWordtypes.get(wordtype) / (words_after_h + 4700));
				}

				segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

				if (r == 0) {
					h2 = segments[0].word;
				}
				for (SegmentOfWord segment : segments) {
					if (r > segment.left && r <= segment.right) {
						h2 = segment.word;
					}
				}

				System.out.println(h2);
			} else if (t == 2) {
				h1 = Integer.valueOf(args[3]);
				h2 = Integer.valueOf(args[4]);
			}

			while (h2 != 9 && h2 != 10 && h2 != 12) {

				double r = rng.nextDouble();
				int w = 0;
				// TODO Generate new word using h1,h2

				int words_after_h1h2 = 0;
				// hashmap stores the wordtype and count occurrence of the word type
				for (int i = 0; i < voc.size(); i++) {
					countsOfWordtypes.put(i, 1);
				}
				// countsOfWordtypes = new HashMap<>();
				for (int i = 0; i < corpus.size() - 2; i++) {
					if (corpus.get(i).equals(h1) && corpus.get(i + 1).equals(h2)) {
						words_after_h1h2++;
						// puts the count after h1h2 into the count occurrence
						countsOfWordtypes.put(corpus.get(i + 2),
								countsOfWordtypes.getOrDefault(corpus.get(i + 2), 0) + 1);
					}
				}
				// hashmap stores wordtype and the probability from flag 100 inside
				probabilitiesOfWordtypes = new HashMap<>();
				for (Integer wordtype : countsOfWordtypes.keySet()) {
					probabilitiesOfWordtypes.put(wordtype,
							(double) countsOfWordtypes.get(wordtype) / (words_after_h1h2 + 4700));
				}

				segments = getProbabilityIntervals(probabilitiesOfWordtypes, numOfWordtypes);

				if (r == 0) {
					w = segments[0].word;
				}
				for (SegmentOfWord segment : segments) {
					if (r > segment.left && r <= segment.right) {
						w = segment.word;
					}
				}
				System.out.println(w);
				h1 = h2;
				h2 = w;
			}
		}
		return;
	}
}
